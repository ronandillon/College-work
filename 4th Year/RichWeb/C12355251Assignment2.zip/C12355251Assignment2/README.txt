Hi Cathy, 

I added the users names to the comments and added the feed of blog entries like we discussed in the demo. 

You can access the website at https://testytest2.firebaseapp.com/

Regards, 

Ronan. 